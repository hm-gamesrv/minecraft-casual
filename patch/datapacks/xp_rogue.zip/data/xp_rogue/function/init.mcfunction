scoreboard objectives add xp_level dummy
scoreboard objectives add tier dummy
scoreboard objectives add prev_tier dummy
scoreboard objectives add target_hp dummy
scoreboard objectives add current_hp dummy
scoreboard objectives add target_speed dummy
scoreboard objectives add current_speed dummy
scoreboard objectives add target_kb dummy
scoreboard objectives add current_kb dummy
scoreboard objectives add target_mining dummy
scoreboard objectives add current_mining dummy
scoreboard objectives add target_fall dummy
scoreboard objectives add current_fall dummy
scoreboard objectives add target_damage dummy
scoreboard objectives add current_damage dummy
scoreboard objectives add target_luck dummy
scoreboard objectives add current_luck dummy
tellraw @a ["",{"text":"[Data Pack] ","color":"gold"},{"text":"XP Rogue System Online","color":"white"}]
