# target = (1.0 + 0.1 * S) * 10
scoreboard players set @s target_mining 10
execute if score @s tier matches 1 run scoreboard players set @s target_mining 11
execute if score @s tier matches 2 run scoreboard players set @s target_mining 12
execute if score @s tier matches 3 run scoreboard players set @s target_mining 13
execute if score @s tier matches 4 run scoreboard players set @s target_mining 14
execute if score @s tier matches 5 run scoreboard players set @s target_mining 15
execute store result score @s current_mining run attribute @s minecraft:player.block_break_speed base get 10
execute unless score @s current_mining = @s target_mining run function xp_rogue:update_mining
