execute if score @s target_fall matches 30 run attribute @s minecraft:generic.safe_fall_distance base set 3.0
execute if score @s target_fall matches 34 run attribute @s minecraft:generic.safe_fall_distance base set 3.4
execute if score @s target_fall matches 38 run attribute @s minecraft:generic.safe_fall_distance base set 3.8
execute if score @s target_fall matches 42 run attribute @s minecraft:generic.safe_fall_distance base set 4.2
execute if score @s target_fall matches 46 run attribute @s minecraft:generic.safe_fall_distance base set 4.6
execute if score @s target_fall matches 50 run attribute @s minecraft:generic.safe_fall_distance base set 5.0
