# Feedback when tier changes
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
title @s actionbar {"translate":"xp_rogue.tier_up","fallback":"你感觉自己变强了"}
