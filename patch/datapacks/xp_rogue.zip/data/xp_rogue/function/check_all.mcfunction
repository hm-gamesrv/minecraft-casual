# Calculate tier (S=0..5) from xp_level
execute store result score @s xp_level run experience query @s levels
scoreboard players set @s tier 0
execute if score @s xp_level matches 5..9 run scoreboard players set @s tier 1
execute if score @s xp_level matches 10..14 run scoreboard players set @s tier 2
execute if score @s xp_level matches 15..19 run scoreboard players set @s tier 3
execute if score @s xp_level matches 20..24 run scoreboard players set @s tier 4
execute if score @s xp_level matches 25.. run scoreboard players set @s tier 5
# Tier change feedback
execute unless score @s tier = @s prev_tier run function xp_rogue:on_tier_change
scoreboard players operation @s prev_tier = @s tier

# Dispatch to per-stat modules
function xp_rogue:check_health
function xp_rogue:check_speed
function xp_rogue:check_knockback
function xp_rogue:check_mining
function xp_rogue:check_fall
function xp_rogue:check_damage
function xp_rogue:check_luck
