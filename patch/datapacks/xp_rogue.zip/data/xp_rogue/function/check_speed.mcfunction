# target = (0.1 + 0.004 * S) * 1000
scoreboard players set @s target_speed 100
execute if score @s tier matches 1 run scoreboard players set @s target_speed 104
execute if score @s tier matches 2 run scoreboard players set @s target_speed 108
execute if score @s tier matches 3 run scoreboard players set @s target_speed 112
execute if score @s tier matches 4 run scoreboard players set @s target_speed 116
execute if score @s tier matches 5 run scoreboard players set @s target_speed 120
execute store result score @s current_speed run attribute @s minecraft:generic.movement_speed base get 1000
execute unless score @s current_speed = @s target_speed run function xp_rogue:update_speed
