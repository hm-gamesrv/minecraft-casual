# target = (1.0 + 0.4 * S) * 10
scoreboard players set @s target_damage 10
execute if score @s tier matches 1 run scoreboard players set @s target_damage 14
execute if score @s tier matches 2 run scoreboard players set @s target_damage 18
execute if score @s tier matches 3 run scoreboard players set @s target_damage 22
execute if score @s tier matches 4 run scoreboard players set @s target_damage 26
execute if score @s tier matches 5 run scoreboard players set @s target_damage 30
execute store result score @s current_damage run attribute @s minecraft:generic.attack_damage base get 10
execute unless score @s current_damage = @s target_damage run function xp_rogue:update_damage
