# target = 0.2 * S * 10
scoreboard players set @s target_luck 0
execute if score @s tier matches 1 run scoreboard players set @s target_luck 2
execute if score @s tier matches 2 run scoreboard players set @s target_luck 4
execute if score @s tier matches 3 run scoreboard players set @s target_luck 6
execute if score @s tier matches 4 run scoreboard players set @s target_luck 8
execute if score @s tier matches 5 run scoreboard players set @s target_luck 10
execute store result score @s current_luck run attribute @s minecraft:generic.luck base get 10
execute unless score @s current_luck = @s target_luck run function xp_rogue:update_luck
