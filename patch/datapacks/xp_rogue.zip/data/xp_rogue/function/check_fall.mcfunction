# target = (3.0 + 0.4 * S) * 10
scoreboard players set @s target_fall 30
execute if score @s tier matches 1 run scoreboard players set @s target_fall 34
execute if score @s tier matches 2 run scoreboard players set @s target_fall 38
execute if score @s tier matches 3 run scoreboard players set @s target_fall 42
execute if score @s tier matches 4 run scoreboard players set @s target_fall 46
execute if score @s tier matches 5 run scoreboard players set @s target_fall 50
execute store result score @s current_fall run attribute @s minecraft:generic.safe_fall_distance base get 10
execute unless score @s current_fall = @s target_fall run function xp_rogue:update_fall
