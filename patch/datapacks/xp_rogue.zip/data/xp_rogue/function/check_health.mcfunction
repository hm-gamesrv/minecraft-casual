# target = 20 + 2 * S
scoreboard players set @s target_hp 20
execute if score @s tier matches 1 run scoreboard players set @s target_hp 22
execute if score @s tier matches 2 run scoreboard players set @s target_hp 24
execute if score @s tier matches 3 run scoreboard players set @s target_hp 26
execute if score @s tier matches 4 run scoreboard players set @s target_hp 28
execute if score @s tier matches 5 run scoreboard players set @s target_hp 30
execute store result score @s current_hp run attribute @s minecraft:generic.max_health base get 1
execute unless score @s current_hp = @s target_hp run function xp_rogue:update_health
