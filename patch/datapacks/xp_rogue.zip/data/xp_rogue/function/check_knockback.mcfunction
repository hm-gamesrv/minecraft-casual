# target = 0.2 * S * 100
scoreboard players set @s target_kb 0
execute if score @s tier matches 1 run scoreboard players set @s target_kb 20
execute if score @s tier matches 2 run scoreboard players set @s target_kb 40
execute if score @s tier matches 3 run scoreboard players set @s target_kb 60
execute if score @s tier matches 4 run scoreboard players set @s target_kb 80
execute if score @s tier matches 5 run scoreboard players set @s target_kb 100
execute store result score @s current_kb run attribute @s minecraft:generic.knockback_resistance base get 100
execute unless score @s current_kb = @s target_kb run function xp_rogue:update_knockback
