execute as @a run function xp_rogue:check_all
