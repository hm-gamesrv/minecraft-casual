execute if score @s target_speed matches 100 run attribute @s minecraft:generic.movement_speed base set 0.1
execute if score @s target_speed matches 104 run attribute @s minecraft:generic.movement_speed base set 0.104
execute if score @s target_speed matches 108 run attribute @s minecraft:generic.movement_speed base set 0.108
execute if score @s target_speed matches 112 run attribute @s minecraft:generic.movement_speed base set 0.112
execute if score @s target_speed matches 116 run attribute @s minecraft:generic.movement_speed base set 0.116
execute if score @s target_speed matches 120 run attribute @s minecraft:generic.movement_speed base set 0.12
