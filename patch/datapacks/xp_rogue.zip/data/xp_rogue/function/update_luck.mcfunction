execute if score @s target_luck matches 0 run attribute @s minecraft:generic.luck base set 0.0
execute if score @s target_luck matches 2 run attribute @s minecraft:generic.luck base set 0.2
execute if score @s target_luck matches 4 run attribute @s minecraft:generic.luck base set 0.4
execute if score @s target_luck matches 6 run attribute @s minecraft:generic.luck base set 0.6
execute if score @s target_luck matches 8 run attribute @s minecraft:generic.luck base set 0.8
execute if score @s target_luck matches 10 run attribute @s minecraft:generic.luck base set 1.0
