execute if score @s target_damage matches 10 run attribute @s minecraft:generic.attack_damage base set 1.0
execute if score @s target_damage matches 14 run attribute @s minecraft:generic.attack_damage base set 1.4
execute if score @s target_damage matches 18 run attribute @s minecraft:generic.attack_damage base set 1.8
execute if score @s target_damage matches 22 run attribute @s minecraft:generic.attack_damage base set 2.2
execute if score @s target_damage matches 26 run attribute @s minecraft:generic.attack_damage base set 2.6
execute if score @s target_damage matches 30 run attribute @s minecraft:generic.attack_damage base set 3.0
