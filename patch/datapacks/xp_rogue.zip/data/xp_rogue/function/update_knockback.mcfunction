execute if score @s target_kb matches 0 run attribute @s minecraft:generic.knockback_resistance base set 0.0
execute if score @s target_kb matches 20 run attribute @s minecraft:generic.knockback_resistance base set 0.2
execute if score @s target_kb matches 40 run attribute @s minecraft:generic.knockback_resistance base set 0.4
execute if score @s target_kb matches 60 run attribute @s minecraft:generic.knockback_resistance base set 0.6
execute if score @s target_kb matches 80 run attribute @s minecraft:generic.knockback_resistance base set 0.8
execute if score @s target_kb matches 100 run attribute @s minecraft:generic.knockback_resistance base set 1.0
