execute if score @s target_mining matches 10 run attribute @s minecraft:player.block_break_speed base set 1.0
execute if score @s target_mining matches 11 run attribute @s minecraft:player.block_break_speed base set 1.1
execute if score @s target_mining matches 12 run attribute @s minecraft:player.block_break_speed base set 1.2
execute if score @s target_mining matches 13 run attribute @s minecraft:player.block_break_speed base set 1.3
execute if score @s target_mining matches 14 run attribute @s minecraft:player.block_break_speed base set 1.4
execute if score @s target_mining matches 15 run attribute @s minecraft:player.block_break_speed base set 1.5
